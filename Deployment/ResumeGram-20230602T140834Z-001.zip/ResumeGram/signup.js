
  
    function myFunction() {
      window.location.href = "faceebook.html";
    }
  